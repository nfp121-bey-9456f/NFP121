/**
 * Model a location in a city.
 * 
 * @author David J. Barnes and Michael Kölling
 * @version 2016.02.29
 */
public class Location
{
    /**
     * Constructor for objects of class Location
     */
    public Location()
    {
    }
}
